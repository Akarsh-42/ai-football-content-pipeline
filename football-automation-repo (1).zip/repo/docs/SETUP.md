# Setup

## Prerequisites

- An [n8n](https://n8n.io) instance (self-hosted or cloud)
- API keys / accounts for:
  - [API-Football](https://www.api-football.com/) (api-sports.io)
  - [Groq](https://console.groq.com/) (for `llama-3.1-8b-instant`)
  - A text-to-speech provider (VoiceRSS or ElevenLabs)
  - [Creatomate](https://creatomate.com/) with a configured video template
  - Google Cloud project with Drive, Sheets, and YouTube Data API enabled (OAuth2)

## Import the workflow

1. In n8n: **Workflows → Import from File**
2. Select `workflow/Football_Automation.sanitized.json`
3. Re-attach credentials in each node (the JSON ships with credential
   references stripped — n8n will prompt you to select/create credentials
   for each node that needs one: Groq, Google Drive, Google Sheets, YouTube)
4. Replace the placeholder values (`{{API_SPORTS_KEY}}`,
   `{{CREATOMATE_API_KEY}}`, `{{VOICERSS_API_KEY}}`) in the relevant HTTP
   Request node header/URL fields with your own keys, or wire them through
   n8n's credential system instead of inline headers (recommended).

## Google Sheet structure

The pipeline reads/writes a Sheet used as a lightweight content queue + log.
Minimum columns:

| column | purpose |
|---|---|
| `row_number` | row identifier used for the update step |
| `topic` | content angle fed into the LLM prompt |
| `video_type` | used to pick a Creatomate template/style |
| `status` | written back after each run |

## Creatomate template

The render call expects a template with at least two text layers
(`Text-1`, `Text-2` in the current config) — adjust the `modifications`
object in the render HTTP node to match your own template's layer names.

## Running it

- Test with **Execute workflow** in the n8n editor before activating the
  Schedule Trigger.
- Once verified, set the trigger interval and toggle the workflow to
  **Active** to run unattended.

## Security

- Never commit a real `.env` or the unsanitized workflow export — both are
  excluded via `.gitignore`.
- If you ever export a workflow directly from n8n for sharing, check for
  inline API keys in `HTTP Request` header parameters before publishing —
  n8n does not sanitize these on export.
