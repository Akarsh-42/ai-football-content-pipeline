/**
 * Node: "Code in JavaScript"
 * Position in pipeline: after live fixture fetch, before LLM commentary generation
 *
 * Purpose:
 *   Transforms raw API-Football fixture JSON into a flat, normalized object
 *   that downstream nodes (Groq LLM, Creatomate, YouTube) can consume directly.
 *   Also handles the "no live matches right now" fallback so the pipeline
 *   never breaks the schedule — it falls back to a default topic/fixture
 *   instead of failing silently.
 *
 * Input:  $json.response  -> array of live fixtures from api-sports.io
 * Reads:  "Get row(s) in sheet" node -> per-run topic/video_type config
 * Output: single flattened object consumed by the LLM Chain prompt
 */

const response = $json.response;

// Fallback path: no live fixtures currently in progress.
// Rather than erroring out and killing the scheduled run, default to a
// known evergreen matchup so the channel still publishes on schedule.
if (!response || response.length === 0) {
  return [{
    json: {
      status_msg: 'No live fixtures',
      topic: 'World Cup football facts',
      video_type: 'fastest_goal',
      row_number: 2,
      home: 'Brazil',
      away: 'Argentina',
      homeGoals: 0,
      awayGoals: 0,
      minute: 45,
      stadium: 'Unknown Stadium',
      status: 'Match Over',
      title: '🌍 Brazil vs Argentina | AI Commentary #shorts',
      description: '#football #soccer #shorts'
    }
  }];
}

const match = response[0];

// Per-run content config, pulled from a Google Sheet acting as a simple
// queue/config store. Defaults protect against the sheet being empty
// or the lookup failing.
let topic = 'World Cup football facts';
let video_type = 'fastest_goal';
let row_number = 2;

try {
  topic = $('Get row(s) in sheet').first().json.topic;
  video_type = $('Get row(s) in sheet').first().json.video_type;
  row_number = $('Get row(s) in sheet').first().json.row_number;
} catch (e) {
  // Sheet lookup failed — proceed with safe defaults above rather than
  // throwing and breaking the scheduled run.
}

const home = match.teams.home.name;
const away = match.teams.away.name;
const homeGoals = match.goals.home ?? 0;
const awayGoals = match.goals.away ?? 0;
const minute = match.fixture.status.elapsed;
const stadium = match.fixture.venue.name ?? 'Unknown Stadium';
const status = match.fixture.status.long;
const score = `${homeGoals}-${awayGoals}`;

const title = `🌍 ${home} vs ${away} ${score} | AI Commentary #shorts`;
const description = `🔥 ${home} vs ${away} | Score: ${score} | Minute: ${minute}\nStadium: ${stadium}\n\nSubscribe for daily AI football shorts! 📺🌍\n\n#football #soccer #shorts #FIFA`;

return [{
  fixture: match.fixture.id,
  home,
  away,
  homeGoals,
  awayGoals,
  minute,
  stadium,
  status,
  title,
  description,
  topic,
  video_type,
  row_number
}];
